public class sym {
    public static final int EOF = 0;
    public static final int UNKNOWN = 1;
    public static final int BEGINARRAY= 10;
    public static final int ENDARRAY= 11;
    public static final int BEGINOBJECT= 12;
    public static final int ENDOBJECT= 13;
    public static final int NAMESEPARATOR = 14;
    public static final int VALUESEPARATOR = 15;
    public static final int FALSE = 16;
    public static final int NULL = 17;
    public static final int TRUE = 18;
    public static final int NUMBER = 19;
    public static final int STRING = 20;

}
