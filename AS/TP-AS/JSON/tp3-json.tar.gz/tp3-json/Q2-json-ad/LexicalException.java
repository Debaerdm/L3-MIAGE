public class LexicalException extends Exception{
  public LexicalException(){super();}
  public LexicalException(String message) {super(message);}
}
