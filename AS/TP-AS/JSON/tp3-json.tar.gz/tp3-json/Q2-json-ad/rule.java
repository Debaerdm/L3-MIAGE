public class rule {
    public static final int JSON_text = 0;
    public static final int OBJECT = 1;
    public static final int ARRAY= 2;
    public static final int MEMBER= 3;
    public static final int VALUE= 4;

}
