Mathieu Debaerdemaeker TP AS - JFlex

Pour lancer chaque exercice il y a un launch.sh il faut le lancer et ils utiliseront le script jflex dans le dossier jflex ici même
