public class sym {
    public static final int EOF = 0;
    public static final int LT = 1;
    public static final int LTSLASH = 2;
    public static final int GT = 3;
    public static final int SLASHGT = 4;
    public static final int NAME = 5;
    public static final int CONTENT = 8;
	public static final int ATTRIBUT = 9;
    public static final int UNKNOWN = 42;
}
