package microcobol;

import java.util.*;

public abstract class Objet {
	//retourne une représentation ASCII de l'instruction
	public abstract String toString();
}
