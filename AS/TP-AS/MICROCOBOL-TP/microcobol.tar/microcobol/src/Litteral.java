package microcobol;

import java.util.*;

public abstract class Litteral extends Objet {
}
