package microcobol;

import java.util.*;

public abstract class Instruction {
	//retourne une représentation ASCII de l'instruction
	public abstract String toString();
}
