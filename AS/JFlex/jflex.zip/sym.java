public class sym {
  // Ajouter factorielle
  public static final int FACTO = 42;
  //
  public static final int IDENT = 12;
  public static final int PARFER = 10;
  public static final int MULT = 7;
  public static final int SET = 2;
  public static final int PAROUV = 9;
  public static final int EOF = 0;
  public static final int PLUS = 5;
  public static final int EGAL = 4;
  public static final int ENTIER = 11;
  public static final int DIV = 8;
  public static final int error = 1;
  public static final int POINTV = 3;
  public static final int MOINS = 6;
}
