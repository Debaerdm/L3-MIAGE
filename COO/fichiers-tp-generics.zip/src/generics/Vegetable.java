package generics;

public interface Vegetable {}
