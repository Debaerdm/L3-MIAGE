For launch this application use command java -jar TP1-Collector-GROUPE-1-DEBAERDEMAEKER-Mathieu-VAILLANT-Guillaume.jar in your terminal. We used different type and sub-type in exercices. We used generics type to vegetable(carrot..) and fruit(apple..).

3 full explain methods :

- take():  take one  vegetable or fruit (verify condition : if the collector haven't object).
- giveTo(): give to a object in collector to the other collector 
- drop(): remove the carried object and return the object removed
