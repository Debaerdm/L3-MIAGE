/*-* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                                        Philippe Marquet --- <marquet@lifl.fr>
                                        05 Mar 1998
    File:  tp.c
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef lint
static const char *WHAT_STRING = "" ;
#endif /* lint */

#include <stdlib.h>
#include <stdio.h>

#include "erreurs.h"

void fs_df (void)
{
  erreur = NYI ;
  perreur ("fs_df") ;
	   
}

void fs_fsck (void)
{
  erreur = NYI ;
  perreur ("fs_fsck") ;

}

